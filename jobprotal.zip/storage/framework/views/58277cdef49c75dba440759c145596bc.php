<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-language" aria-hidden="true"></i> <span class="title">Languages</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.languages')); ?>" class="nav-link "> <span class="title">List Languages</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.language')); ?>" class="nav-link "> <span class="title">Add new Language</span> </a> </li>
    </ul>
</li><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/shared/side_bars/language.blade.php ENDPATH**/ ?>