<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-question-circle" aria-hidden="true"></i> <span class="title">FAQs</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.faqs')); ?>" class="nav-link "> <span class="title">List FAQs</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.faq')); ?>" class="nav-link "> <span class="title">Add new FAQ</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.faqs')); ?>" class="nav-link "> <span class="title">Sort FAQs</span> </a> </li>
    </ul>
</li><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/shared/side_bars/faq.blade.php ENDPATH**/ ?>