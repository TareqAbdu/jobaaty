<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-globe" aria-hidden="true"></i> <span class="title">States</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.states')); ?>" class="nav-link "> <span class="title">List States</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.state')); ?>" class="nav-link ">  <span class="title">Add new State</span> </a> </li>
    </ul>
</li><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/shared/side_bars/state.blade.php ENDPATH**/ ?>