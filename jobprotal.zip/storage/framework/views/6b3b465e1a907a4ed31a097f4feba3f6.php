<?php echo APFrmErrHelp::showErrorsNotice($errors); ?>

<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="form-body">
    <fieldset>
        <legend>Enter Analytics Code:</legend>
        <div class="form-group <?php echo APFrmErrHelp::hasError($errors, 'ganalytics'); ?>">
           
			<?php echo Form::textarea('ganalytics', null, array('class'=>'form-control', 'contenteditable'=>'true', 'id'=>'ganalytics', 'placeholder'=>'Add Analytics Code Here')); ?>

			
			
            <?php echo APFrmErrHelp::showErrors($errors, 'ganalytics'); ?>    
        </div>        
    </fieldset>


    <fieldset>
        <legend>Google Tag Manager for Head:</legend>
        <div class="form-group <?php echo APFrmErrHelp::hasError($errors, 'google_tag_manager_for_head'); ?>">
           
			<?php echo Form::textarea('google_tag_manager_for_head', null, array('class'=>'form-control', 'contenteditable'=>'true', 'id'=>'google_tag_manager_for_head', 'placeholder'=>'Add Google Tag Manager for Head Code Here')); ?>

			
			
            <?php echo APFrmErrHelp::showErrors($errors, 'google_tag_manager_for_head'); ?>    
        </div>        
    </fieldset>

    <fieldset>
        <legend>Google Tag Manager for Body:</legend>
        <div class="form-group <?php echo APFrmErrHelp::hasError($errors, 'google_tag_manager_for_body'); ?>">
           
			<?php echo Form::textarea('google_tag_manager_for_body', null, array('class'=>'form-control', 'contenteditable'=>'true', 'id'=>'google_tag_manager_for_body', 'placeholder'=>'Add Google Tag Manager for Body Code Here')); ?>

			
			
            <?php echo APFrmErrHelp::showErrors($errors, 'google_tag_manager_for_body'); ?>    
        </div>        
    </fieldset>

</div>
<?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/site_setting/forms/googleAnalytics_form.blade.php ENDPATH**/ ?>