<?php echo APFrmErrHelp::showErrorsNotice($errors); ?>

<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="form-body">
    <fieldset>
        <legend>Enter Username:</legend>
        <div class="form-group <?php echo APFrmErrHelp::hasError($errors, 'username_jobg8'); ?>">
           
			<?php echo Form::text('username_jobg8', null, array('class'=>'form-control', 'contenteditable'=>'true', 'id'=>'username_jobg8', 'placeholder'=>'Enter Username Here')); ?>

			
			
            <?php echo APFrmErrHelp::showErrors($errors, 'username_jobg8'); ?>    
        </div>        
    </fieldset>


    <fieldset>
        <legend>Enter Password:</legend>
        <div class="form-group <?php echo APFrmErrHelp::hasError($errors, 'password_jobg8'); ?>">
           
			<?php echo Form::text('password_jobg8', null, array('class'=>'form-control', 'contenteditable'=>'true', 'id'=>'password_jobg8', 'placeholder'=>'Enter Password Here')); ?>

			
			
            <?php echo APFrmErrHelp::showErrors($errors, 'password_jobg8'); ?>    
        </div>        
    </fieldset>

    <fieldset>
        <legend>Enter Account Number:</legend>
        <div class="form-group <?php echo APFrmErrHelp::hasError($errors, 'accountnumber_jobg8'); ?>">
           
			<?php echo Form::text('accountnumber_jobg8', null, array('class'=>'form-control', 'contenteditable'=>'true', 'id'=>'accountnumber_jobg8', 'placeholder'=>'Enter Account Number')); ?>

			
			
            <?php echo APFrmErrHelp::showErrors($errors, 'accountnumber_jobg8'); ?>    
        </div>        
    </fieldset>

    <fieldset>
        <legend>If you want to import jobs from jobg8 api then click on this link:</legend>
        <a target="_blank" href="<?php echo e(url('/job8')); ?>"><?php echo e(url('/job8')); ?></a>   
    </fieldset>

</div>
<?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/site_setting/forms/jobg8_API_form.blade.php ENDPATH**/ ?>