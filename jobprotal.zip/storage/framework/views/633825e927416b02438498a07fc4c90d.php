<?php if(Auth::guard('company')->check()): ?>
<form action="<?php echo e(route('job.seeker.list')); ?>" method="get">
    <div class="searchbar">
		<div class="srchbox">		
		<div class="input-group">
		  <input type="text"  name="search" id="empsearch" value="<?php echo e(Request::get('search', '')); ?>" class="form-control" placeholder="<?php echo e(__('Enter Skills or Job Seeker Details')); ?>" autocomplete="off" />
		  <span class="input-group-btn">
			<input type="submit" class="btn" value="<?php echo e(__('Search Job Seeker')); ?>">
		  </span>
		</div>
		</div>
		
       
        
    </div>
</form>
<?php else: ?>
		
	
	<form class="banner-form" action="<?php echo e(route('job.list')); ?>" method="get">
		<div class="row justify-content-center">
			<div class="col-md-4">
				<div class="form-group">
					<label for="jbsearch"><?php echo e(__('Enter Skills or job title')); ?>:</label>
					<input type="text" name="search" id="jbsearch" value="<?php echo e(Request::get('search', '')); ?>" class="form-control" placeholder="<?php echo e(__('Enter Skills or job title')); ?>" autocomplete="off">
				</div>
			</div>
	
			<div class="col-md-4">
				<div class="form-group">
					<label for="functional_area_id"><?php echo e(__('Select Functional Area')); ?>:</label>
					<?php echo Form::select('functional_area_id[]', ['' => __('Select Functional Area')]+$functionalAreas, Request::get('functional_area_id', null), array('class'=>'form-control', 'id'=>'functional_area_id')); ?>

				</div>
			</div>
	
			<div class="col-md-4">
			
				<input type="submit" class="find-btn" value="<?php echo e(__('Search Job Seeker')); ?>">

			</div>
		</div>
	</form>
    	
<?php endif; ?><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/includes/search_form.blade.php ENDPATH**/ ?>