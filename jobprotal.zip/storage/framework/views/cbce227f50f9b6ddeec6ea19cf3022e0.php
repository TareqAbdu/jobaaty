<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-book" aria-hidden="true"></i> <span class="title">Major Subjects</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.major.subjects')); ?>" class="nav-link "> <span class="title">List Major Subjects</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.major.subject')); ?>" class="nav-link "> <span class="title">Add new Major Subject</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.major.subjects')); ?>" class="nav-link "> <span class="title">Sort Major Subjects</span> </a> </li>
    </ul>
</li><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/shared/side_bars/major_subject.blade.php ENDPATH**/ ?>