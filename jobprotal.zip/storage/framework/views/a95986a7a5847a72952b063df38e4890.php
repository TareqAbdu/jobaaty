<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-level-up" aria-hidden="true"></i> <span class="title">Degree Levels</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.degree.levels')); ?>" class="nav-link ">  <span class="title">List Degree Levels</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.degree.level')); ?>" class="nav-link ">  <span class="title">Add new Degree Level</span> </a> </li>
    </ul>
</li><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/shared/side_bars/degree_level.blade.php ENDPATH**/ ?>