
<?php $__env->startSection('content'); ?>
<!-- Header start -->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header end --> 
<!-- Inner Page Title start -->
<?php echo $__env->make('includes.inner_top_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Inner Page Title end -->
<div class="about-wraper">
    <div class="container">

    <div class="largebanner shadow3 mt-0">
<div class="adin">
<?php echo $siteSetting->cms_page_ad; ?>

</div>
<div class="clearfix"></div>
</div>



        
    <h2><?php echo e($cmsContent->page_title); ?></h2>
    <p><?php echo $cmsContent->page_content; ?></p>
            
       
    </div>  
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/cms/cms_page.blade.php ENDPATH**/ ?>