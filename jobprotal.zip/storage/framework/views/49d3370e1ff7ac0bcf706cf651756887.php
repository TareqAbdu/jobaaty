<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="icon-wrench"></i> <span class="title">Site Settings</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('edit.site.setting')); ?>" class="nav-link "> <span class="title">Manage Site Settings</span> </a> </li>
    </ul>
</li><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/shared/side_bars/site_setting.blade.php ENDPATH**/ ?>