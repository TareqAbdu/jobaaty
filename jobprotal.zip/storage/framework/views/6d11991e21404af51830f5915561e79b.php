<div class="pageTitle">
    <div class="container">        
                <h1 class="page-heading"><?php echo e($page_title); ?></h1>
                <div class="breadCrumb"><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a> / <span><?php echo e($page_title); ?></span></div>
           
    </div>
</div><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/includes/inner_page_title.blade.php ENDPATH**/ ?>