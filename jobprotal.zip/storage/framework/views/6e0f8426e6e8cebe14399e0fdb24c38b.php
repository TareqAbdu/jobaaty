<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-graduation-cap" aria-hidden="true"></i> <span class="title">Result Types</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="<?php echo e(route('list.result.types')); ?>" class="nav-link "> <span class="title">List Result Types</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('create.result.type')); ?>" class="nav-link "> <span class="title">Add new Result Type</span> </a> </li>
        <li class="nav-item  "> <a href="<?php echo e(route('sort.result.types')); ?>" class="nav-link "> <span class="title">Sort Result Types</span> </a> </li>
    </ul>
</li><?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/admin/shared/side_bars/result_type.blade.php ENDPATH**/ ?>