<section class="bg-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="footer-item mt-4 mt-lg-0 me-lg-5">
                    <h4 class="text-white mb-4"><?php echo e($siteSetting->site_name); ?></h4>
                    <p class="text-white-50"><?php echo e(__('It is a long established fact that a reader will be of a page reader will be of at its layout.')); ?></p>
                    <p class="text-white mt-3"><?php echo e(__('Follow Us on:')); ?></p>
                    <ul class="footer-social-menu list-inline mb-0">
                        <!-- Include Social Media Links -->
                        <?php echo $__env->make('includes.footer_social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div><!--end col-->
            
            <div class="col-lg-2 col-6">
                <div class="footer-item mt-4 mt-lg-0">
                    <p class="fs-16 text-white mb-4"><?php echo e(__('Quick Links')); ?></p>
                    <ul class="list-unstyled footer-list mb-0">
                        <li><a href="<?php echo e(route('index')); ?>"><i class="mdi mdi-chevron-right"></i> <?php echo e(__('Home')); ?></a></li>
                        <li><a href="<?php echo e(route('contact.us')); ?>"><i class="mdi mdi-chevron-right"></i> <?php echo e(__('Contact Us')); ?></a></li>
                        <li class="postad"><a href="<?php echo e(route('post.job')); ?>"><i class="mdi mdi-chevron-right"></i> <?php echo e(__('Post a Job')); ?></a></li>
                        <li><a href="<?php echo e(route('faq')); ?>"><i class="mdi mdi-chevron-right"></i> <?php echo e(__('FAQs')); ?></a></li>
                        <?php $__currentLoopData = $show_in_footer_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $cmsContent = App\CmsContent::getContentBySlug($footer_menu->page_slug);
                        ?>
                        <li class="<?php echo e(Request::url() == route('cms', $footer_menu->page_slug) ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('cms', $footer_menu->page_slug)); ?>">
                                <i class="mdi mdi-chevron-right"></i> <?php echo e($cmsContent->page_title); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div><!--end col-->

            <div class="col-lg-2 col-6">
                <div class="footer-item mt-4 mt-lg-0">
                    <p class="fs-16 text-white mb-4"><?php echo e(__('Jobs By Functional Area')); ?></p>
                    <ul class="list-unstyled footer-list mb-0">
                        <?php
                        $functionalAreas = App\FunctionalArea::getUsingFunctionalAreas(10);
                        ?>
                        <?php $__currentLoopData = $functionalAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $functionalArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('job.list', ['functional_area_id[]'=>$functionalArea->functional_area_id])); ?>">
                            <i class="mdi mdi-chevron-right"></i> <?php echo e($functionalArea->functional_area); ?>

                        </a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div><!--end col-->

            <div class="col-lg-2 col-6">
                <div class="footer-item mt-4 mt-lg-0">
                    <p class="fs-16 text-white mb-4"><?php echo e(__('Jobs By Industry')); ?></p>
                    <ul class="list-unstyled footer-list mb-0">
                        <?php
                        $industries = App\Industry::getUsingIndustries(10);
                        ?>
                        <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('job.list', ['industry_id[]'=>$industry->industry_id])); ?>">
                            <i class="mdi mdi-chevron-right"></i> <?php echo e($industry->industry); ?>

                        </a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div><!--end col-->

            <div class="col-lg-2 col-6">
                <div class="footer-item mt-4 mt-lg-0">
                    <p class="fs-16 text-white mb-4"><?php echo e(__('Contact Us')); ?></p>
                    <div class="address text-white-50"><?php echo e($siteSetting->site_street_address); ?></div>
                    <div class="email text-white-50 mt-2"> 
                        <a href="mailto:<?php echo e($siteSetting->mail_to_address); ?>" class="text-white-50">
                            <?php echo e($siteSetting->mail_to_address); ?>

                        </a> 
                    </div>
                    <div class="phone text-white-50 mt-2"> 
                        <a href="tel:<?php echo e($siteSetting->site_phone_primary); ?>" class="text-white-50">
                            <?php echo e($siteSetting->site_phone_primary); ?>

                        </a>
                    </div>
                </div>
            </div><!--end col-->

        </div><!--end row-->
    </div><!--end container-->
</section>

<div class="footer-alt">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="text-white-50 text-center mb-0">
                    2024 &copy; <?php echo e($siteSetting->site_name); ?> - <?php echo e(__('All Rights Reserved')); ?>.
                    <?php echo e(__('Design by')); ?> <a href="https://themeforest.net/search/themesdesign" target="_blank" class="text-reset text-decoration-underline">Themesdesign</a>
                </p>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->
</div><!--end footer-alt-->

<?php /**PATH C:\Users\tarka\OneDrive\Desktop\jobprotal\resources\views/includes/footer.blade.php ENDPATH**/ ?>